# زبان تعریف فرآیند
هر فرآیند یک trigger و فهرستی از step ها دارد. step می‌تواند action، condition یا webhook باشد.
