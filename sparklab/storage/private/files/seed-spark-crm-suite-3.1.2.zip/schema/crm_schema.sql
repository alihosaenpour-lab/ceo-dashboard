-- Spark CRM v3.1 — schema
CREATE TABLE leads (id BIGSERIAL PRIMARY KEY, name TEXT, phone TEXT, stage TEXT DEFAULT 'new');
CREATE TABLE activities (id BIGSERIAL PRIMARY KEY, lead_id BIGINT REFERENCES leads(id), note TEXT, at TIMESTAMPTZ DEFAULT now());
