# ساختار سورس
- app/ : لایه UI (React Native)
- server/ : API سمت سرور (Node.js)
- docs/api.md : مستند endpoints
