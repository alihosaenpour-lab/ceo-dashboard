-- Spark Booking v1.9
CREATE TABLE services (id SERIAL PRIMARY KEY, title TEXT, duration_min INT, price BIGINT);
CREATE TABLE appointments (id BIGSERIAL PRIMARY KEY, service_id INT REFERENCES services(id), starts_at TIMESTAMPTZ, customer TEXT, status TEXT DEFAULT 'booked');
