# فهرست کامپوننت‌ها
Button، Card، Table، Modal، Toast، Tabs، Form inputs، Chart wrappers — همگی RTL و Dark-ready.
