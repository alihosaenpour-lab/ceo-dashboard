-- Spark POS Cloud v2.4 — PostgreSQL schema
CREATE TABLE sales (id BIGSERIAL PRIMARY KEY, branch_id INT NOT NULL, total BIGINT NOT NULL, paid_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE products (id SERIAL PRIMARY KEY, sku TEXT UNIQUE, name TEXT, price BIGINT);
